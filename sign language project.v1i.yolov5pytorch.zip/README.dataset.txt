# sign language project > 2024-10-06 3:54am
https://universe.roboflow.com/aman-sikarwar/sign-language-project-qwo9c

Provided by a Roboflow user
License: CC BY 4.0

